# Replica-interference simulation

Cleaned simulation code extracted from `replica_qutip.py`.

## Current scope

This version intentionally preserves the existing effective block-noise model rather than changing the physics. It provides a clean baseline for debugging before implementing gate-local noise.

The main protocol is

\[
\rho^{\otimes m}\rightarrow H_A\rightarrow C(V_m)
\rightarrow H_A\rightarrow Z_A,
\]

with unitary folding

\[
U_c=U(U^\dagger U)^c,\qquad s=2c+1.
\]

Noise can currently be applied after every complete \(U\) or \(U^\dagger\) block to the ancilla, replica/system qubits, or all qubits.

## Layout

- `replica_sim/state.py`: density-matrix validation and \(\mathrm{Tr}(\rho^m)\).
- `replica_sim/permutation.py`: cyclic and controlled cyclic permutation operators.
- `replica_sim/noise.py`: phase flip/dephasing, depolarizing, amplitude damping.
- `replica_sim/protocol.py`: replica-interference experiment and effective block-noise folding.
- `replica_sim/estimators.py`: R-ZNE and Richardson estimators.
- `replica_sim/analysis.py`: log-linear diagnostics.
- `replica_sim/config.py`: simulation defaults.
- `experiments/`: executable experiments.
- `tests/`: sanity checks.
- `results/data`: numerical data.
- `results/figures`: generated figures.
- `legacy/`: original rough notebook-derived script, retained for provenance only.

## Run

From this directory:

```bash
python experiments/run_single.py
```

Run tests with:

```bash
pytest
```

## Next stage

The next physics upgrade should replace effective post-block noise with gate-local noise inside the physical implementation of the controlled permutation. The current package is deliberately kept separate from that upgrade so the two models can be compared cleanly.
