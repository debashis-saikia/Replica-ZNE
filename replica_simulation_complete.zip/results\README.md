# Results

`data/` stores numerical outputs. `figures/` stores generated figures.

Do not manually edit result files. The source parameters and experiment scripts live under `experiments/`.
